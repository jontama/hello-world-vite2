<template>
  <p>{{ msg }}</p>
</template>

<script>
export default {
  inject: ['msg'],
}
</script>
