import { createApp } from 'vue'
import Ex from './Component.vue'

createApp(Ex).mount('#app')