import { createApp } from 'vue'
import Ex from './Ex318.vue'

createApp(Ex).mount('#app')