import { createApp } from 'vue'
/*import App from './App.vue'

import './assets/main.css'

createApp(App).mount('#app')*/


import Ex from './components/Ex336.vue'

//import './assets/main.css'

createApp(Ex).mount('#app')